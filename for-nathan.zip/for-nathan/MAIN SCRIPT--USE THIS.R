###################################################################################################
#Title: Simulation with Non-Severe Infection (Dynamic Model)
#Author: Hailey Park
#Date: September 1, 2023
###################################################################################################

rm(list=ls())
gc()

#Set working directory
setwd("") 

#Load libraries
library(readr)
library(dplyr)
library(tidyverse)
library(ggplot2)
library(tidyr)
library(tibble)
library(reshape2)
library(lubridate)
library(scales)
library(foreach)
library(doParallel)
library(here)
library(data.table)

# Set up the number of cores used for parallelization.
# Use detectCores() to find out how many cores are available.
num_cores <- detectCores() - 1
registerDoParallel(num_cores)

#Saving function for parallelizing
comb <- function(...) {
  mapply('rbind', ..., SIMPLIFY=FALSE)
}


#Set up folder structure to save simulation results
dir.create("simulation-results")
dir.create("simulation-results/lower")

for (pop_strat in c("75+ strategy", "65+ strategy", "18+ strategy")) {
  dir.create(paste0("simulation-results/lower/", pop_strat))
  
  for (uptake in c("realistic", "optimistic")) {
    dir.create(paste0("simulation-results/lower/", pop_strat, "/", uptake))
    
    for (intervention in c("1-Booster", "Annual-Booster", "Biannual-Booster")) {
      dir.create(paste0("simulation-results/lower/", pop_strat, "/", uptake, "/", intervention))
      
    }
  }
}

###################################################################################################
#75+ Population Strategy; Realistic Uptake

source(here::here("~/simulation-data-inputs-dynamic-with-age-mixing.R"))
source(here::here("~//intervention-functions-dynamic with mixing-75+.R"))

#Assigning uptake 
set.seed(88)
inspection <- clean_df %>% 
  lapply(realistic_vax_assignment) 

#Running 1 Booster (will only do for 75+ pop strat since this is same across all population strategies)
set.seed(88)
sim_df_1B <- foreach (i = 1:25, .packages = c("dplyr", "data.table")) %dopar% {
  results <- oneBoosterSimulation(inspection[[1]])
  list(results)
}

for (i in c(1:25)){
  write.csv(sim_df_1B[[i]][[1]], paste0("simulation-results/lower/75+ strategy/realistic/1-Booster/", i, ".csv"))
}

#Running Annual Booster
set.seed(88)
sim_df_aB <- foreach (i = 1:25, .packages = c("dplyr", "data.table")) %dopar% {
  results <- annualBoosterSimulation(inspection[[1]])
  list(results)
}

for (i in c(1:25)){
  write.csv(sim_df_aB[[i]][[1]], paste0("simulation-results/lower/75+ strategy/realistic/Annual-Booster/", i, ".csv"))
}

#Running Biannual Booster
set.seed(88)
sim_df_bB <- foreach (i = 1:25, .packages = c("dplyr", "data.table")) %dopar% {
  results <- biannualBoosterSimulation(inspection[[1]])
  list(results)
}

for (i in c(1:25)){
  write.csv(sim_df_bB[[i]][[1]], paste0("simulation-results/lower/75+ strategy/realistic/Biannual-Booster/", i, ".csv"))
}

###################################################################################################
#65+ Population Strategy; Realistic Uptake

source(here::here("~/simulation-data-inputs-dynamic-with-age-mixing.R"))
source(here::here("~//intervention-functions-dynamic with mixing-65+.R"))

set.seed(88)
inspection <- clean_df %>% 
  lapply(realistic_vax_assignment) 

#Running Annual Booster
set.seed(88)
sim_df_aB <- foreach (i = 1:25, .packages = c("dplyr", "data.table")) %dopar% {
  results <- annualBoosterSimulation(inspection[[1]])
  list(results)
}

for (i in c(1:25)){
  write.csv(sim_df_aB[[i]][[1]], paste0("simulation-results/lower/65+ strategy/realistic/Annual-Booster/", i, ".csv"))
}

#Running Biannual Booster
set.seed(88)
sim_df_bB <- foreach (i = 1:25, .packages = c("dplyr", "data.table")) %dopar% {
  results <- biannualBoosterSimulation(inspection[[1]])
  list(results)
}

for (i in c(1:25)){
  write.csv(sim_df_bB[[i]][[1]], paste0("simulation-results/lower/65+ strategy/realistic/Biannual-Booster/", i, ".csv"))
}

###################################################################################################
#18+ Population Strategy; Realistic Uptake

source(here::here("~/simulation-data-inputs-dynamic-with-age-mixing.R"))
source(here::here("~//intervention-functions-dynamic with mixing-18+.R"))

set.seed(88)
inspection <- clean_df %>% 
  lapply(realistic_vax_assignment) 

#Running Annual Booster
set.seed(88)
sim_df_aB <- foreach (i = 1:25, .packages = c("dplyr", "data.table")) %dopar% {
  results <- annualBoosterSimulation(inspection[[1]])
  list(results)
}

for (i in c(1:25)){
  write.csv(sim_df_aB[[i]][[1]], paste0("simulation-results/lower/18+ strategy/realistic/Annual-Booster/", i, ".csv"))
}

#Running Biannual Booster
set.seed(88)
sim_df_bB <- foreach (i = 1:25, .packages = c("dplyr", "data.table")) %dopar% {
  results <- biannualBoosterSimulation(inspection[[1]])
  list(results)
}

for (i in c(1:25)){
  write.csv(sim_df_bB[[i]][[1]], paste0("simulation-results/lower/18+ strategy/realistic/Biannual-Booster/", i, ".csv"))
}
###################################################################################################
#75+ Population Strategy; Optimistic Uptake

source(here::here("~/simulation-data-inputs-dynamic-with-age-mixing.R"))
source(here::here("~//intervention-functions-dynamic with mixing-75+.R"))

set.seed(88)
inspection <- clean_df %>% 
  lapply(optimistic_vax_assignment) 

#Running 1 Booster (will only do for 75+ pop strat since this is same across all population strategies)
set.seed(88)
sim_df_1B <- foreach (i = 1:25, .packages = c("dplyr", "data.table")) %dopar% {
  results <- oneBoosterSimulation(inspection[[1]])
  list(results)
}

for (i in c(1:25)){
  write.csv(sim_df_1B[[i]][[1]], paste0("simulation-results/lower/75+ strategy/optimistic/1-Booster/", i, ".csv"))
}

#Running Annual Booster
set.seed(88)
sim_df_aB <- foreach (i = 1:25, .packages = c("dplyr", "data.table")) %dopar% {
  results <- annualBoosterSimulation(inspection[[1]])
  list(results)
}

for (i in c(1:25)){
  write.csv(sim_df_aB[[i]][[1]], paste0("simulation-results/lower/75+ strategy/optimistic/Annual-Booster/", i, ".csv"))
}

#Running Biannual Booster
set.seed(88)
sim_df_bB <- foreach (i = 1:25, .packages = c("dplyr", "data.table")) %dopar% {
  results <- biannualBoosterSimulation(inspection[[1]])
  list(results)
}

for (i in c(1:25)){
  write.csv(sim_df_bB[[i]][[1]], paste0("simulation-results/lower/75+ strategy/optimistic/Biannual-Booster/", i, ".csv"))
}

###################################################################################################
#65+ Population Strategy; Optimistic Uptake

source(here::here("~/simulation-data-inputs-dynamic-with-age-mixing.R"))
source(here::here("~//intervention-functions-dynamic with mixing-65+.R"))

set.seed(88)
inspection <- clean_df %>% 
  lapply(optimistic_vax_assignment) 

#Running Annual Booster
set.seed(88)
sim_df_aB <- foreach (i = 1:25, .packages = c("dplyr", "data.table")) %dopar% {
  results <- annualBoosterSimulation(inspection[[1]])
  list(results)
}

for (i in c(1:25)){
  write.csv(sim_df_aB[[i]][[1]], paste0("simulation-results/lower/65+ strategy/optimistic/Annual-Booster/", i, ".csv"))
}

#Running Biannual Booster
set.seed(88)
sim_df_bB <- foreach (i = 1:25, .packages = c("dplyr", "data.table")) %dopar% {
  results <- biannualBoosterSimulation(inspection[[1]])
  list(results)
}

for (i in c(1:25)){
  write.csv(sim_df_bB[[i]][[1]], paste0("simulation-results/lower/65+ strategy/optimistic/Biannual-Booster/", i, ".csv"))
}
###################################################################################################
#18+ Population Strategy; Optimistic Uptake

source(here::here("~/simulation-data-inputs-dynamic-with-age-mixing.R"))
source(here::here("~//intervention-functions-dynamic with mixing-18+.R"))

set.seed(88)
inspection <- clean_df %>% 
  lapply(optimistic_vax_assignment) 

#Running Annual Booster
set.seed(88)
sim_df_aB <- foreach (i = 1:25, .packages = c("dplyr", "data.table")) %dopar% {
  results <- annualBoosterSimulation(inspection[[1]])
  list(results)
}

for (i in c(1:25)){
  write.csv(sim_df_aB[[i]][[1]], paste0("simulation-results/lower/18+ strategy/optimistic/Annual-Booster/", i, ".csv"))
}

#Running Biannual Booster
set.seed(88)
sim_df_bB <- foreach (i = 1:25, .packages = c("dplyr", "data.table")) %dopar% {
  results <- biannualBoosterSimulation(inspection[[1]])
  list(results)
}

for (i in c(1:25)){
  write.csv(sim_df_bB[[i]][[1]], paste0("simulation-results/lower/18+ strategy/optimistic/Biannual-Booster/", i, ".csv"))
}
###################################################################################################

