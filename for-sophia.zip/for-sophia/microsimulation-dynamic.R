###################################################################################################
#Title: Simulation with Non-Severe Infection (Dynamic Model)
#Author: Hailey Park
#Date: September 1, 2023
###################################################################################################

rm(list=ls())
gc()

setwd("~/Stanford Research/booster-timing") 

#Load libraries
library(readr)
library(dplyr)
library(tidyverse)
library(ggplot2)
library(tidyr)
library(tibble)
library(reshape2)
library(lubridate)
library(scales)
library(foreach)
library(doParallel)
library(here)
library(data.table)

# Set up the number of cores used for parallelization.
# Use detectCores() to find out how many cores are available.
num_cores <- detectCores() - 1
registerDoParallel(num_cores)

#Run calibration
source(here::here("simulation-dynamic model-calibration.R"))

#Set up data inputs for dynamic model simulations
source(here::here("simulation-data-inputs-dynamic.R"))


#Set up folder to store results
#results/(18+ strategy OR 65+ strategy OR 75+ strategy)/(realistic OR optimistic)

#Going to do 25 simulation runs for each analysis in parallel

comb <- function(...) {
  mapply('rbind', ..., SIMPLIFY=FALSE)
}

sims_oneBooster <- function(df, strategy, vax_type){
  
  sim_df <- foreach (i = 1:2, .combine='comb', .multicombine=TRUE) %dopar% {
    results <- oneBoosterSimulation(df)
    list(results[[1]])
  }

  write.csv(sim_df, paste0("results/", strategy, "/", vax_type, "/entire_pop_simulation_1Booster_weekly_average.csv"))
  
}

sims_annualBooster <- function(df, strategy, vax_type){
  
  sim_df <- foreach (i = 1:2, .combine='comb', .multicombine=TRUE) %dopar% {
    results <- annualBoosterSimulation(df)
    list(results[[1]])
  }
  
  write.csv(sim_df, paste0("results/", strategy, "/", vax_type, "/entire_pop_simulation_annualBooster_weekly_average.csv"))
  
}

sims_biannualBooster <- function(df, strategy, vax_type){
  
  sim_df <- foreach (i = 1:2, .combine='comb', .multicombine=TRUE) %dopar% {
    results <- biannualBoosterSimulation(df)
    list(results[[1]])
  }
  
  write.csv(sim_df, paste0("results/", strategy, "/", vax_type, "/entire_pop_simulation_biannualBooster_weekly_average.csv"))
  
}


strategy_18plus_realistic <- function(df){
  
  source(here::here("intervention-functions-dynamic-18+.R"))
  set.seed(88)
  vax_assignment <- realistic_vax_assignment(clean_df)
  
  sims_oneBooster(vax_assignment, "18+ strategy", "realistic")
  sims_annualBooster(vax_assignment, "18+ strategy", "realistic")
  sims_biannualBooster(vax_assignment, "18+ strategy", "realistic")
  
}

strategy_65plus_realistic <- function(df){
  source(here::here("intervention-functions-dynamic-65+.R"))
  set.seed(88)
  vax_assignment <- realistic_vax_assignment(clean_df)
  
  sims_oneBooster(vax_assignment, "65+ strategy", "realistic")
  sims_annualBooster(vax_assignment, "65+ strategy", "realistic")
  sims_biannualBooster(vax_assignment, "65+ strategy", "realistic")
  
}

strategy_75plus_realistic <- function(df){
  source(here::here("intervention-functions-dynamic-75+.R"))
  set.seed(88)
  vax_assignment <- realistic_vax_assignment(clean_df)
  
  sims_oneBooster(vax_assignment, "75+ strategy", "realistic")
  sims_annualBooster(vax_assignment, "75+ strategy", "realistic")
  sims_biannualBooster(vax_assignment, "75+ strategy", "realistic")
  
}

strategy_18plus_optimistic <- function(df){
  
  source(here::here("intervention-functions-dynamic-18+.R"))
  set.seed(88)
  vax_assignment <- optimistic_vax_assignment(clean_df)
  
  sims_oneBooster(vax_assignment, "18+ strategy", "optimistic")
  sims_annualBooster(vax_assignment, "18+ strategy", "optimistic")
  sims_biannualBooster(vax_assignment, "18+ strategy", "optimistic")
  
}

strategy_65plus_optimistic <- function(df){
  source(here::here("intervention-functions-dynamic-65+.R"))
  set.seed(88)
  vax_assignment <- optimistic_vax_assignment(clean_df)
  
  sims_oneBooster(vax_assignment, "65+ strategy", "optimistic")
  sims_annualBooster(vax_assignment, "65+ strategy", "optimistic")
  sims_biannualBooster(vax_assignment, "65+ strategy", "optimistic")
  
}

strategy_75plus_optimistic <- function(df){
  source(here::here("intervention-functions-dynamic-75+.R"))
  set.seed(88)
  vax_assignment <- optimistic_vax_assignment(clean_df)
  
  sims_oneBooster(vax_assignment, "75+ strategy", "optimistic")
  sims_annualBooster(vax_assignment, "75+ strategy", "optimistic")
  sims_biannualBooster(vax_assignment, "75+ strategy", "optimistic")
  
}
###########################################################################################